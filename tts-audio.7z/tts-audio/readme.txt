=== TTS Audio ===
Contributors: ducnv999
Donate link: https://paypal.me/ducwp
Tags: tts, text-to-speech, tts audio, text to speech, text to voice, read text
Requires at least: 4.7
Tested up to: 5.4.2
Stable tag: 1.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

TTS Audio is a WordPress plugin that helps you convert text-to-speech in WordPress in multiple languages.

== Description ==

TTS Audio is a WordPress plugin that helps you convert text-to-speech in WordPress in multiple languages.

Languages: English, German, French, Spanish, Italian, Vietnamese, Japanese, Korean, ect.

Each language come with multiple voices.

[TTS Audio Demo](https://demo.gearthemes.com/ttsaudio/ "View Live Demo")

**Features**:

*   Supports multiple languages with multiple voices.
*   Host audio files on your web and dide true mp3 file path for security
*   The widget is ready for adding to sidebars.
*   Supports many skins with game of colors.
*   Custom skins in Pro version.
*   Responsive based on Element width

== Screenshots ==

1. screenshot-1.png.
2. screenshot-2.png.
3. screenshot-3.png.

== Changelog ==

= 1.0 =
* Plugin relesed.
