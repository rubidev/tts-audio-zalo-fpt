<?php
/*
Plugin Name: TTS Audio ZALO FPT
Plugin URI: https://github.com/rubidev/tts-audio-zalo-fpt
Description: Chuyển văn bản thành giọng nói AI (ZALO, FPT, ..)
Author: GearThemes - Custom by DANGNGOCSON.COM
Author URI: https://dangngocson.com
Version: 1.1
Text Domain: ttsaudio
Domain Path: /languages
*/

define('TTSAUDIO_URI', plugin_dir_url( __FILE__ ));
define('TTSAUDIO_DIR', plugin_dir_path( __FILE__ ));

require_once( TTSAUDIO_DIR . 'inc/class.TTSAudio.php');
require_once( TTSAUDIO_DIR . 'inc/options.php');
require_once( TTSAUDIO_DIR . 'inc/metabox.php');
require_once( TTSAUDIO_DIR . 'inc/class.Widgets.php');


$tts = new TTSAudio;

add_action( 'plugins_loaded', 'ttsaudio_load_textdomain' );
function ttsaudio_load_textdomain() {
  load_plugin_textdomain( 'ttsaudio', false, basename( dirname( __FILE__ ) ) . '/languages' );
}

add_action( 'wp_enqueue_scripts', 'ttsaudio_front_enqueue' );
function load_script_to_remove_arrow(){
?>
<script>document.addEventListener('DOMContentLoaded', () => {
	const source =  document.querySelector('audio').querySelector('source').getAttribute('src');
	const audio = document.querySelector('audio');
	
	// For more options see: https://github.com/sampotts/plyr/#options
	// captions.update is required for captions to work with hls.js
	
	if (!Hls.isSupported()) {
		audio.src = source;
	} else {
		// For more Hls.js options, see https://github.com/dailymotion/hls.js
		const hls = new Hls();
		hls.loadSource(source);
		hls.attachMedia(audio);
		window.hls = hls;
		
		// Handle changing captions
		
	}
	
	// Expose player so it can be used from the console
	//window.player = player;
});
</script>
<?php
}
add_action( 'wp_footer', 'load_script_to_remove_arrow' );

function ttsaudio_front_enqueue(){

	wp_enqueue_style( 'ttsaudio-plyr',  TTSAUDIO_URI . 'assets/css/plyr.css' );
  wp_enqueue_style( 'ttsaudio-style',  TTSAUDIO_URI . 'assets/css/style.css' );

  wp_enqueue_script( 'jquery');
	wp_enqueue_script( 'ttsaudio-plyr', TTSAUDIO_URI . 'assets/js/plyr.js', [], false, true);
	wp_enqueue_script( 'ttsaudio-playlist', TTSAUDIO_URI . 'assets/js/plyr-playlist.js', ['ttsaudio-plyr'], false, true);
	wp_enqueue_script( 'ttsaudio-html5media', TTSAUDIO_URI . 'assets/js/html5media.min.js', [], false, true);
	wp_enqueue_script( 'ttsaudio-rangetouch', TTSAUDIO_URI . 'assets/js/rangetouch.js', ['jquery'], false, true);
	wp_enqueue_script( 'ttsaudio-ResizeSensor', TTSAUDIO_URI . 'assets/js/ResizeSensor.js', ['jquery'], false, true);
	wp_enqueue_script( 'ttsaudio-ElementQueries', TTSAUDIO_URI . 'assets/js/ElementQueries.js', ['jquery'], false, true);
	wp_enqueue_script( 'ttsaudio-hls', plugins_url( 'assets/js/hls.js', __FILE__ ));

  $inline = 'const ranges = RangeTouch.setup(\'input[type="range"]\');';
  wp_add_inline_script( 'ttsaudio-rangetouch', $inline );
}

add_filter( 'the_content', array($tts, 'ttsAudioContent') );

add_filter( 'query_vars', function( $query_vars ){
    $query_vars[] = 'ttsaudio';
    return $query_vars;
} );

add_action( 'template_include', array($tts, 'template_include') );
add_action( 'wp_enqueue_scripts', array($tts, 'single_script' ) );
